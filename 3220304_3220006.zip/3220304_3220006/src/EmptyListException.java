
/**
 * EmptyListException is a simple Exception.
 * It is thrown by a List when get methods are called on an empty list.
 */
public class EmptyListException extends Exception {
}
